<script type="text/javascript">
function jsFunction(){
alert('Gagal Simpan Perubahan!');
window.location.href = ".user/isi_formulir";
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>
