<script type="text/javascript">
function jsFunction(){
alert('Username Dan Password Salah!');
window.location.href = "./login";
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>
