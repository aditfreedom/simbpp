<script type="text/javascript">
function jsFunction(){
alert('Berhasil Ubah Password');
window.location.href = "./datapengguna";
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>
