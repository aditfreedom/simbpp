<script type="text/javascript">
function jsFunction(){
alert('Berhasil Ubah Data');
window.location.href = "./edit";
}
</script>
<?php
echo '<script type="text/javascript">jsFunction();</script>';
?>




